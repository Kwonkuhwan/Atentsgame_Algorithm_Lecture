#define _CRT_SECURE_NO_WARNINGS
#include "LinkedQueue.h"

int main( void )
{
    Node* Popped;
    LinkedQueue* Queue;

	char data[100];
	int priority = 0;

    LQ_CreateQueue(&Queue );
    
   // LQ_Enqueue( Queue, LQ_CreateNode("abc", 1) );
   // LQ_Enqueue( Queue, LQ_CreateNode("def", 1) );
   // LQ_Enqueue( Queue, LQ_CreateNode("efg", 2) );
   // LQ_Enqueue( Queue, LQ_CreateNode("hij", 3) );

	while (1) {
		printf("ť�� ������ ����Ÿ�� �Է��ϼ���: (pritority data), exit: -1(priority)");
		scanf("%d %s", &priority, data);
		if (priority == -1) {
			break;
		}

		LQ_Enqueue(Queue, LQ_CreateNode(data, priority));



		// �Է� ����Ÿ ���
		printf("\n�Էµ���Ÿ ���\n");
		Node* Current = Queue->Front;
		while (Current != NULL) {
			printf("Current->Priority: %d, Data: %s\n", Current->Priority, Current->Data);

			Current = Current->NextNode;
		}
	}


	for (int i = 0; i < 10; i++) {
		
	}

    printf("Queue Size : %d\n", Queue->Count);

    while ( LQ_IsEmpty( Queue ) == 0 )
    {
        Popped = LQ_Dequeue( Queue );

        printf( "Dequeue: pritority: %d,  data: %s \n", Popped->Priority, Popped->Data );

        LQ_DestroyNode( Popped );
    }

    LQ_DestroyQueue( Queue );

    return 0;
}